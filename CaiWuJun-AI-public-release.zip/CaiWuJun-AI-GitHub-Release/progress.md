# CaiWuJun AI 进度记录

## 2026-06-03

- 创建项目目录：`CaiWuJun-AI`
- 创建文档目录：`CaiWuJun-AI/docs`
- 创建第一版项目计划：`task_plan.md`
- 创建需求发现记录：`findings.md`
- 创建进度记录：`progress.md`

当前状态：

- Phase 1：概念与角色定稿，进行中
- 下一步：补齐 `docs/persona.md`、`docs/opening-lines.md`、`docs/visual-direction.md`

## 2026-06-03 桌面应用原型

- 根据用户新需求，将角色名统一为“蔡武君”
- 复制第一张低多边形小男孩图片为应用主视觉：`Assets/CaiWuJunCharacter.png`
- 创建 SwiftPM macOS 应用骨架
- 创建核心模块：时间问候、人设提示词、OpenAI Responses API 请求与解析
- 创建 `CaiWuJunCoreCheck` 本地检查器
- 创建 SwiftUI 桌面界面
- 创建麦克风语音输入控制器
- 创建 `.app` 打包脚本：`scripts/build-app.sh`
- 成功生成并打开：`build/蔡武君 AI.app`
- 已验证应用窗口显示、角色图片显示、输入框和无 API Key 提示

## 2026-06-03 上下文记忆与动画

- 增加本地会话模型：`Conversation`
- 增加本地记忆存储：`ConversationStore`
- 增加多个独立对话窗口列表
- 新建窗口时显示“正在重启，尝试重启...”
- 切换窗口时读取对应本地上下文
- 删除窗口时删除对应上下文记忆
- 增加教学模式提示词
- 支持从 `OPENAI_API_KEY` 环境变量读取 API Key
- 增加系统语音朗读 AI 回复
- 增加说话时嘴巴开合动画
- 增加每 3 秒眨眼动画
- 增加惊讶、生气、开心、伤心表情状态
- 使用内置图片生成工具生成表情素材表，并保存为 `Assets/CaiWuJunExpressionSheet.png`

## 2026-06-03 按钮与 AI 后端修复

- 修复顶部按钮点击困难：取消隐藏标题栏，改为标准标题栏窗口
- 将顶部按钮改为 36px 固定点击区和可见背景
- 将麦克风和发送按钮加大到 46px 点击区
- 检查本机 AI 软件：发现 `Doubao.app`、`ChatGPT.app`，但没有本地 API 服务端口
- 检查豆包桌面 App：存在 `doubao://` 深链，但不能作为稳定回答 API
- 增加豆包火山方舟 Chat Completions 后端
- 增加 OpenAI Responses 后端
- 增加自定义/本地 OpenAI 兼容 Chat 后端
- 设置页默认使用豆包火山方舟：`https://ark.cn-beijing.volces.com/api/v3`
- 支持环境变量 `ARK_API_KEY` 和 `OPENAI_API_KEY`
- 实际验证：窗口列表按钮、设置按钮、新窗口按钮均可点击

## 2026-06-03 本机 Codex 后端与按钮重做

- 验证本机 `/opt/homebrew/bin/codex` 可用
- 增加 `codexCLI` AI 后端，通过 `codex exec` 非交互生成回复
- 将默认 AI 后端改为本机 Codex CLI，不需要 API Key
- 写入本机应用默认设置：`aiProvider=codexCLI`
- 将顶部图标按钮全部改成大文字按钮：`记忆`、`新窗`、`教学`、`AI`
- 将输入区按钮改成大文字按钮：`语音`、`发送`
- 实际验证：发送消息后进入“蔡武君正在思考...”
- 实际验证：蔡武君通过 Codex 后端返回真实回答并触发朗读

## 2026-06-03 Codex 后端崩溃修复

- 定位崩溃根因：双击打开 `.app` 时 PATH 缺少 `/usr/local/bin`，导致 Codex 子进程报 `env: node: No such file or directory`
- 在 `CodexCLIClient` 启动子进程时显式注入稳定 PATH：`/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin`
- 将发送给 Codex 的上下文限制为最近 10 条消息，避免长聊后上下文过大导致不稳定
- 将失败提示改成可恢复状态，不再表现为角色崩溃
- 清理本地会话中的旧“连接 AI 核心失败”消息，避免污染后续上下文
- 实际验证：在旧游戏设计对话中继续发送消息，蔡武君成功回复并朗读
