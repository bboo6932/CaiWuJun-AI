#!/bin/sh
set -eu

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
APP_DIR="$ROOT_DIR/build/蔡武君 AI.app"
CONTENTS_DIR="$APP_DIR/Contents"
MACOS_DIR="$CONTENTS_DIR/MacOS"
RESOURCES_DIR="$CONTENTS_DIR/Resources"

cd "$ROOT_DIR"
swift build -c release

rm -rf "$APP_DIR"
mkdir -p "$MACOS_DIR" "$RESOURCES_DIR"

cp ".build/release/CaiWuJunAI" "$MACOS_DIR/CaiWuJunAI"
cp "Info.plist" "$CONTENTS_DIR/Info.plist"
cp "Assets/CaiWuJunCharacter.png" "$RESOURCES_DIR/CaiWuJunCharacter.png"
cp "Assets/CaiWuJunExpressionSheet.png" "$RESOURCES_DIR/CaiWuJunExpressionSheet.png"

chmod +x "$MACOS_DIR/CaiWuJunAI"

if command -v codesign >/dev/null 2>&1; then
  codesign --force --deep --sign - "$APP_DIR" >/dev/null 2>&1 || true
fi

echo "$APP_DIR"
