#!/bin/sh
set -eu

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
CONTENT="$ROOT_DIR/Sources/CaiWuJunAI/ContentView.swift"
BUILD="$ROOT_DIR/scripts/build-app.sh"

grep -q 'CaiWuJunExpressionSheet' "$CONTENT"
grep -q 'ExpressionFrame' "$CONTENT"
grep -q 'frameIndex' "$CONTENT"
grep -q 'mouthOpen' "$CONTENT"
grep -q 'expressionFrame' "$CONTENT"
grep -q 'scaledToFit' "$CONTENT"
grep -q 'cropWidth' "$CONTENT"
grep -q 'CaiWuJunExpressionSheet.png' "$BUILD"

if grep -q 'mouthOverlay' "$CONTENT"; then
  echo "mouthOverlay should not be used; expression sheet frames should drive mouth movement" >&2
  exit 1
fi

if grep -A14 'Image(nsImage: image)' "$CONTENT" | grep -q 'scaleEffect(0.92'; then
  echo "portrait foreground should fit inside the character platform instead of zoom-cropping the face" >&2
  exit 1
fi

echo "visual state checks passed"
