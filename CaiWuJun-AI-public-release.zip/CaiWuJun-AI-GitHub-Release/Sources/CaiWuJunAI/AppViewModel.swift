import CaiWuJunCore
import AVFoundation
import Foundation

@MainActor
final class AppViewModel: NSObject, ObservableObject, AVSpeechSynthesizerDelegate {
    enum Expression: String {
        case neutral
        case surprised
        case angry
        case happy
        case sad
    }

    @Published var conversations: [Conversation] = []
    @Published var selectedConversationID: UUID?
    @Published var messages: [ChatMessage] = []
    @Published var draft = ""
    @Published var providerRaw = UserDefaults.standard.string(forKey: "aiProvider") ?? AIProviderKind.codexCLI.rawValue
    @Published var apiKey = UserDefaults.standard.string(forKey: "aiAPIKey") ?? ProcessInfo.processInfo.environment["ARK_API_KEY"] ?? ProcessInfo.processInfo.environment["OPENAI_API_KEY"] ?? ""
    @Published var apiBaseURL = UserDefaults.standard.string(forKey: "aiBaseURL") ?? "https://ark.cn-beijing.volces.com/api/v3"
    @Published var model = UserDefaults.standard.string(forKey: "aiModel") ?? "doubao-seed-2-0-lite-260215"
    @Published var isThinking = false
    @Published var statusText = "桌面模式待机中"
    @Published var isSpeaking = false
    @Published var expression: Expression = .neutral
    @Published var showsConversationList = false
    @Published var isTeachingMode = false

    private let store = ConversationStore()
    private let synthesizer = AVSpeechSynthesizer()

    override init() {
        super.init()
        synthesizer.delegate = self
        loadConversations()
    }

    func saveAPIKey() {
        UserDefaults.standard.set(providerRaw, forKey: "aiProvider")
        UserDefaults.standard.set(apiKey, forKey: "aiAPIKey")
        UserDefaults.standard.set(apiBaseURL, forKey: "aiBaseURL")
        UserDefaults.standard.set(model, forKey: "aiModel")
        statusText = (AIProviderKind(rawValue: providerRaw) == .codexCLI || !apiKey.isEmpty) ? "AI 核心已连接" : "还没有配置 API Key"
    }

    func useCodexDefaults() {
        providerRaw = AIProviderKind.codexCLI.rawValue
        apiBaseURL = "local-codex-cli"
        model = "codex"
        apiKey = ""
    }

    func useDoubaoDefaults() {
        providerRaw = AIProviderKind.doubaoArk.rawValue
        apiBaseURL = "https://ark.cn-beijing.volces.com/api/v3"
        model = "doubao-seed-2-0-lite-260215"
    }

    func useOpenAIDefaults() {
        providerRaw = AIProviderKind.openAIResponses.rawValue
        apiBaseURL = "https://api.openai.com/v1"
        model = "gpt-5-mini"
    }

    func useCompatibleDefaults() {
        providerRaw = AIProviderKind.openAICompatible.rawValue
        if apiBaseURL.isEmpty {
            apiBaseURL = "http://127.0.0.1:1234/v1"
        }
        if model.isEmpty {
            model = "local-model"
        }
    }

    func sendDraft() {
        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !isThinking else { return }
        draft = ""
        send(text)
    }

    func send(_ text: String) {
        append(.user, text)

        let provider = AIProviderKind(rawValue: providerRaw) ?? .codexCLI

        guard provider == .codexCLI || !apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            append(.assistant, "我想认真回答你，但现在还没接上 AI 核心。点右上角钥匙，选豆包火山方舟、OpenAI 或自定义接口，再填 API Key；也可以设置环境变量 ARK_API_KEY 或 OPENAI_API_KEY。")
            statusText = "等待 API Key"
            return
        }

        isThinking = true
        statusText = "蔡武君正在思考..."
        let history = messages
        let configuration = AIConfiguration(
            provider: provider,
            apiKey: apiKey,
            baseURL: apiBaseURL,
            model: model
        )
        let prompt = PersonaPrompt.prompt(isTeachingMode: isTeachingMode, memoryTitle: currentConversation?.title ?? "未命名窗口")

        Task {
            do {
                let client = OpenAIClient(configuration: configuration)
                let reply = try await client.send(messages: history, systemPrompt: prompt)
                append(.assistant, reply)
                speak(reply)
                expression = expressionFor(text: reply)
                statusText = "回复完成"
            } catch {
                append(.assistant, "刚刚 AI 核心短路了一下，我已经停在这里，没有丢掉这段对话。你可以直接再发一次，我会只带最近上下文继续接上。错误：\(error.localizedDescription)")
                statusText = "连接失败"
            }
            isThinking = false
        }
    }

    func newConversation() {
        let count = conversations.count + 1
        let restart = "正在重启，尝试重启...好了，我回来了。新窗口已开启，这里的上下文记忆会单独保存在本地。"
        let conversation = Conversation(
            title: "对话窗口 \(count)",
            messages: [
                ChatMessage(role: .assistant, text: restart),
                ChatMessage(role: .assistant, text: GreetingProvider.greeting())
            ]
        )
        conversations.insert(conversation, at: 0)
        selectConversation(conversation.id)
        persist()
        statusText = "新窗口已开启"
    }

    func selectConversation(_ id: UUID) {
        selectedConversationID = id
        guard let selected = conversations.first(where: { $0.id == id }) else { return }
        messages = selected.messages
        isTeachingMode = selected.isTeachingMode
        statusText = "已读取：\(selected.title)"
    }

    func deleteConversation(_ id: UUID) {
        conversations.removeAll { $0.id == id }
        if conversations.isEmpty {
            createInitialConversation()
        } else if selectedConversationID == id {
            selectConversation(conversations[0].id)
        }
        persist()
        statusText = "窗口和本地记忆已删除"
    }

    func toggleTeachingMode() {
        isTeachingMode.toggle()
        updateCurrentConversation { conversation in
            conversation.isTeachingMode = isTeachingMode
            conversation.updatedAt = Date()
        }
        statusText = isTeachingMode ? "教学模式已开启" : "教学模式已关闭"
    }

    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didStart utterance: AVSpeechUtterance) {
        Task { @MainActor in
            self.isSpeaking = true
        }
    }

    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        Task { @MainActor in
            self.isSpeaking = false
            self.expression = .neutral
        }
    }

    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        Task { @MainActor in
            self.isSpeaking = false
            self.expression = .neutral
        }
    }

    private var currentConversation: Conversation? {
        guard let selectedConversationID else { return nil }
        return conversations.first { $0.id == selectedConversationID }
    }

    private func loadConversations() {
        do {
            conversations = try store.load()
        } catch {
            conversations = []
            statusText = "读取本地记忆失败，已新建窗口"
        }

        if conversations.isEmpty {
            createInitialConversation()
        } else {
            conversations.sort { $0.updatedAt > $1.updatedAt }
            selectConversation(conversations[0].id)
        }
    }

    private func createInitialConversation() {
        let conversation = Conversation(
            title: "主窗口",
            messages: [ChatMessage(role: .assistant, text: GreetingProvider.greeting())]
        )
        conversations = [conversation]
        selectConversation(conversation.id)
    }

    private func append(_ role: ChatMessage.Role, _ text: String) {
        let message = ChatMessage(role: role, text: text)
        messages.append(message)
        updateCurrentConversation { conversation in
            conversation.messages = messages
            conversation.updatedAt = Date()
            if role == .user, conversation.title.hasPrefix("对话窗口") || conversation.title == "主窗口" {
                conversation.title = String(text.prefix(12))
            }
        }
    }

    private func updateCurrentConversation(_ mutate: (inout Conversation) -> Void) {
        guard let selectedConversationID,
              let index = conversations.firstIndex(where: { $0.id == selectedConversationID }) else { return }
        mutate(&conversations[index])
        persist()
    }

    private func persist() {
        do {
            try store.save(conversations)
        } catch {
            statusText = "保存本地记忆失败：\(error.localizedDescription)"
        }
    }

    private func speak(_ text: String) {
        synthesizer.stopSpeaking(at: .immediate)
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = AVSpeechSynthesisVoice(language: "zh-CN")
        utterance.rate = 0.48
        utterance.pitchMultiplier = 1.05
        synthesizer.speak(utterance)
    }

    private func expressionFor(text: String) -> Expression {
        let lower = text.lowercased()
        if lower.contains("惊") || lower.contains("啊？") || lower.contains("什么") || lower.contains("震惊") || lower.contains("吓") || lower.contains("害怕") {
            return .surprised
        }
        if lower.contains("生气") || lower.contains("不可以") || lower.contains("可恶") || lower.contains("愤怒") || lower.contains("讨厌") {
            return .angry
        }
        if lower.contains("开心") || lower.contains("太好了") || lower.contains("哈哈") || lower.contains("厉害") || lower.contains("喜欢") || lower.contains("牛") || lower.contains("棒") {
            return .happy
        }
        if lower.contains("难过") || lower.contains("伤心") || lower.contains("眼泪") || lower.contains("对不起") || lower.contains("哭") || lower.contains("委屈") {
            return .sad
        }
        return .neutral
    }
}
