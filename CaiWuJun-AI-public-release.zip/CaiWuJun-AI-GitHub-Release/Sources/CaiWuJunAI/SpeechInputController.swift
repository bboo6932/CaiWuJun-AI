import AVFoundation
import Speech

@MainActor
final class SpeechInputController: NSObject, ObservableObject {
    @Published var isListening = false
    @Published var transcript = ""
    @Published var status = "麦克风待机"

    private let audioEngine = AVAudioEngine()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "zh-CN"))

    func toggleListening(onFinalText: @escaping (String) -> Void) {
        if isListening {
            stopListening(sendFinalText: true, onFinalText: onFinalText)
        } else {
            startListening()
        }
    }

    private func startListening() {
        SFSpeechRecognizer.requestAuthorization { [weak self] speechStatus in
            Task { @MainActor in
                guard let self else { return }
                guard speechStatus == .authorized else {
                    self.status = "语音识别权限未开启"
                    return
                }

                switch AVCaptureDevice.authorizationStatus(for: .audio) {
                case .authorized:
                    self.beginRecognition()
                case .notDetermined:
                    AVCaptureDevice.requestAccess(for: .audio) { allowed in
                        Task { @MainActor in
                            allowed ? self.beginRecognition() : (self.status = "麦克风权限未开启")
                        }
                    }
                default:
                    self.status = "麦克风权限未开启"
                }
            }
        }
    }

    private func beginRecognition() {
        stopListening(sendFinalText: false, onFinalText: { _ in })
        transcript = ""
        status = "正在听你说话..."

        let request = SFSpeechAudioBufferRecognitionRequest()
        request.shouldReportPartialResults = true
        self.request = request

        let input = audioEngine.inputNode
        let format = input.outputFormat(forBus: 0)
        input.removeTap(onBus: 0)
        input.installTap(onBus: 0, bufferSize: 1024, format: format) { buffer, _ in
            request.append(buffer)
        }

        audioEngine.prepare()

        do {
            try audioEngine.start()
        } catch {
            status = "麦克风启动失败：\(error.localizedDescription)"
            return
        }

        isListening = true
        task = recognizer?.recognitionTask(with: request) { [weak self] result, error in
            Task { @MainActor in
                guard let self else { return }
                if let result {
                    self.transcript = result.bestTranscription.formattedString
                }
                if let error {
                    self.status = "语音识别暂停：\(error.localizedDescription)"
                    self.stopListening(sendFinalText: false, onFinalText: { _ in })
                }
            }
        }
    }

    private func stopListening(sendFinalText: Bool, onFinalText: @escaping (String) -> Void) {
        if audioEngine.isRunning {
            audioEngine.stop()
            audioEngine.inputNode.removeTap(onBus: 0)
        }

        request?.endAudio()
        task?.cancel()
        request = nil
        task = nil
        isListening = false

        let finalText = transcript.trimmingCharacters(in: .whitespacesAndNewlines)
        if sendFinalText, !finalText.isEmpty {
            status = "语音已发送"
            transcript = ""
            onFinalText(finalText)
        } else {
            status = "麦克风待机"
        }
    }
}
