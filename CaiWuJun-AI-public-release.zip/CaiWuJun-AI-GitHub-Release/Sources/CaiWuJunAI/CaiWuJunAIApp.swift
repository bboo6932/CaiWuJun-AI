import SwiftUI

@main
struct CaiWuJunAIApp: App {
    var body: some Scene {
        WindowGroup("蔡武君 AI") {
            ContentView()
                .frame(minWidth: 420, idealWidth: 480, maxWidth: 560, minHeight: 640, idealHeight: 760)
        }
        .defaultSize(width: 480, height: 760)
    }
}
