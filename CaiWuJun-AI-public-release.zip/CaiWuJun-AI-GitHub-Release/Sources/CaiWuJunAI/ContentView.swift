import CaiWuJunCore
import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = AppViewModel()
    @StateObject private var speech = SpeechInputController()
    @State private var showsSettings = false
    @State private var isBlinking = false
    @State private var mouthOpen = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 1.0, green: 0.97, blue: 0.91),
                    Color(red: 0.92, green: 0.83, blue: 0.65),
                    Color(red: 0.74, green: 0.88, blue: 0.92)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 14) {
                topBar
                if viewModel.showsConversationList {
                    conversationList
                }
                characterPanel
                chatPanel
                inputPanel
            }
            .padding(18)
        }
        .sheet(isPresented: $showsSettings) {
            SettingsView(
                providerRaw: $viewModel.providerRaw,
                apiKey: $viewModel.apiKey,
                apiBaseURL: $viewModel.apiBaseURL,
                model: $viewModel.model,
                useCodexDefaults: viewModel.useCodexDefaults,
                useDoubaoDefaults: viewModel.useDoubaoDefaults,
                useOpenAIDefaults: viewModel.useOpenAIDefaults,
                useCompatibleDefaults: viewModel.useCompatibleDefaults
            ) {
                viewModel.saveAPIKey()
                showsSettings = false
            }
            .frame(width: 520, height: 420)
        }
        .onAppear {
            startBlinkLoop()
        }
        .onChange(of: viewModel.isSpeaking) { _, speaking in
            if speaking {
                startMouthLoop()
            } else {
                mouthOpen = false
            }
        }
    }

    private var topBar: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("蔡武君 AI")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundStyle(Color(red: 0.12, green: 0.18, blue: 0.25))
                Text(viewModel.statusText)
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(Color(red: 0.2, green: 0.38, blue: 0.52))
            }

            Spacer()

            TopTextButton(title: "记忆", help: "查看所有对话窗口和本地记忆") {
                viewModel.showsConversationList.toggle()
            }

            TopTextButton(title: "新窗", help: "开启一个新对话窗口") {
                viewModel.newConversation()
            }

            TopTextButton(title: viewModel.isTeachingMode ? "教学✓" : "教学", help: viewModel.isTeachingMode ? "关闭教学模式" : "开启教学模式") {
                viewModel.toggleTeachingMode()
            }

            TopTextButton(title: "AI", help: "配置 AI 后端") {
                showsSettings = true
            }
        }
    }

    private var conversationList: some View {
        VStack(spacing: 8) {
            ForEach(viewModel.conversations) { conversation in
                HStack(spacing: 8) {
                    Button {
                        viewModel.selectConversation(conversation.id)
                    } label: {
                        HStack {
                            Image(systemName: conversation.id == viewModel.selectedConversationID ? "bubble.left.and.bubble.right.fill" : "bubble.left.and.bubble.right")
                            Text(conversation.title)
                                .lineLimit(1)
                            Spacer()
                            if conversation.isTeachingMode {
                                Image(systemName: "graduationcap.fill")
                            }
                        }
                        .font(.system(size: 13, weight: .semibold))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 8)
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .background(
                        conversation.id == viewModel.selectedConversationID
                            ? Color(red: 0.98, green: 0.86, blue: 0.58)
                            : Color.white.opacity(0.55),
                        in: RoundedRectangle(cornerRadius: 8)
                    )

                    Button {
                        viewModel.deleteConversation(conversation.id)
                    } label: {
                        Image(systemName: "trash")
                            .font(.system(size: 13, weight: .bold))
                            .frame(width: 28, height: 28)
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(Color(red: 0.58, green: 0.12, blue: 0.10))
                    .help("删除这个窗口和它的本地上下文记忆")
                }
            }
        }
        .padding(10)
        .background(Color.white.opacity(0.45), in: RoundedRectangle(cornerRadius: 8))
    }

    private var characterPanel: some View {
        VStack(spacing: 10) {
            Text(latestAssistantLine)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(Color(red: 0.14, green: 0.18, blue: 0.23))
                .multilineTextAlignment(.center)
                .lineLimit(3)
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .frame(maxWidth: .infinity)
                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 8))
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color(red: 0.83, green: 0.63, blue: 0.22), lineWidth: 1)
                )

            CharacterImage(
                expression: viewModel.expression,
                isBlinking: isBlinking,
                mouthOpen: viewModel.isSpeaking && mouthOpen
            )
                .frame(height: 270)
                .clipShape(RoundedRectangle(cornerRadius: 8))
                .overlay(alignment: .bottomTrailing) {
                    Label(statusBadgeText, systemImage: statusBadgeIcon)
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 7)
                        .background(Color(red: 0.08, green: 0.26, blue: 0.36).opacity(0.86), in: Capsule())
                        .padding(12)
                }
        }
    }

    private var chatPanel: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 10) {
                    ForEach(viewModel.messages) { message in
                        MessageBubble(message: message)
                            .id(message.id)
                    }
                    if viewModel.isThinking {
                        HStack {
                            ProgressView()
                                .controlSize(.small)
                            Text("蔡武君正在认真想...")
                                .font(.system(size: 13, weight: .medium))
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    if !speech.transcript.isEmpty {
                        Text("语音输入：\(speech.transcript)")
                            .font(.system(size: 12))
                            .foregroundStyle(Color(red: 0.12, green: 0.35, blue: 0.52))
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .padding(12)
            }
            .frame(maxHeight: 210)
            .background(Color.white.opacity(0.58), in: RoundedRectangle(cornerRadius: 8))
            .onChange(of: viewModel.messages.count) { _, _ in
                if let id = viewModel.messages.last?.id {
                    withAnimation(.easeOut(duration: 0.2)) {
                        proxy.scrollTo(id, anchor: .bottom)
                    }
                }
            }
        }
    }

    private var inputPanel: some View {
        HStack(spacing: 10) {
            TextField("打字和蔡武君说话...", text: $viewModel.draft, axis: .vertical)
                .textFieldStyle(.plain)
                .lineLimit(1...3)
                .padding(.horizontal, 12)
                .padding(.vertical, 10)
                .background(Color(red: 1.0, green: 0.95, blue: 0.84), in: RoundedRectangle(cornerRadius: 8))
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color(red: 0.82, green: 0.60, blue: 0.20), lineWidth: 1)
                )
                .onSubmit {
                    viewModel.sendDraft()
                }

            Button {
                speech.toggleListening { text in
                    viewModel.send(text)
                }
            } label: {
                Text(speech.isListening ? "停" : "语音")
                    .font(.system(size: 14, weight: .bold))
                    .frame(width: 56, height: 44)
            }
            .buttonStyle(.plain)
            .foregroundStyle(.white)
            .background(speech.isListening ? Color.red : Color(red: 0.14, green: 0.45, blue: 0.65), in: RoundedRectangle(cornerRadius: 8))
            .help(speech.isListening ? "暂停并发送语音输入" : "开始语音输入")

            Button {
                viewModel.sendDraft()
            } label: {
                Text("发送")
                    .font(.system(size: 14, weight: .bold))
                    .frame(width: 56, height: 44)
            }
            .buttonStyle(.plain)
            .foregroundStyle(.white)
            .background(Color(red: 0.80, green: 0.56, blue: 0.15), in: RoundedRectangle(cornerRadius: 8))
            .disabled(viewModel.isThinking)
            .help("发送")
        }
    }

    private var statusBadgeText: String {
        if speech.isListening { return "正在听" }
        if viewModel.isSpeaking { return "正在说话" }
        if viewModel.isTeachingMode { return "教学模式" }
        return "游戏搭档待机"
    }

    private var statusBadgeIcon: String {
        if speech.isListening { return "waveform" }
        if viewModel.isSpeaking { return "speaker.wave.2.fill" }
        if viewModel.isTeachingMode { return "graduationcap.fill" }
        return "gamecontroller.fill"
    }

    private var latestAssistantLine: String {
        viewModel.messages.last(where: { $0.role == .assistant })?.text ?? GreetingProvider.greeting()
    }

    private func startBlinkLoop() {
        Task { @MainActor in
            while true {
                try? await Task.sleep(for: .seconds(3))
                isBlinking = true
                try? await Task.sleep(for: .milliseconds(180))
                isBlinking = false
            }
        }
    }

    private func startMouthLoop() {
        Task { @MainActor in
            while viewModel.isSpeaking {
                mouthOpen.toggle()
                try? await Task.sleep(for: .milliseconds(130))
            }
            mouthOpen = false
        }
    }
}

private struct TopTextButton: View {
    let title: String
    let help: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 13, weight: .bold))
                .foregroundStyle(Color(red: 0.13, green: 0.20, blue: 0.27))
                .frame(minWidth: 48, minHeight: 38)
                .contentShape(Rectangle())
        }
        .buttonStyle(.bordered)
        .background(Color.white.opacity(0.45), in: RoundedRectangle(cornerRadius: 8))
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color(red: 0.83, green: 0.63, blue: 0.22).opacity(0.45), lineWidth: 1)
        )
        .help(help)
    }
}

private struct CharacterImage: View {
    let expression: AppViewModel.Expression
    let isBlinking: Bool
    let mouthOpen: Bool
    private let expressionFrameCount = 7

    private enum ExpressionFrame: Int {
        case neutral = 0
        case blink = 1
        case talk = 2
        case surprised = 3
        case angry = 4
        case happy = 5
        case sad = 6
    }

    var body: some View {
        Group {
            if let sheet = loadExpressionSheet(), let frame = expressionFrameImage(from: sheet) {
                portraitFrame(frame)
            } else if let image = loadImage() {
                Image(nsImage: image)
                    .resizable()
                    .scaledToFill()
            } else {
                ZStack {
                    Color(red: 0.12, green: 0.32, blue: 0.38)
                    Text("蔡武君")
                        .font(.system(size: 42, weight: .bold))
                        .foregroundStyle(.white)
                }
            }
        }
    }

    private var expressionFrame: ExpressionFrame {
        if isBlinking {
            return .blink
        }

        if mouthOpen {
            switch expression {
            case .neutral:
                return .talk
            case .surprised:
                return .surprised
            case .angry:
                return .angry
            case .happy:
                return .happy
            case .sad:
                return .sad
            }
        }

        switch expression {
        case .neutral:
            return .neutral
        case .surprised:
            return .surprised
        case .angry:
            return .angry
        case .happy:
            return .happy
        case .sad:
            return .sad
        }
    }

    private var frameIndex: Int {
        expressionFrame.rawValue
    }

    @ViewBuilder
    private func portraitFrame(_ image: NSImage) -> some View {
        GeometryReader { proxy in
            ZStack(alignment: .bottom) {
                Image(nsImage: image)
                    .resizable()
                    .scaledToFill()
                    .frame(width: proxy.size.width, height: proxy.size.height)
                    .blur(radius: 18)
                    .opacity(0.26)
                    .clipped()

                Image(nsImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(width: proxy.size.width * 0.58, height: proxy.size.height * 0.96, alignment: .bottom)
                    .shadow(color: Color.black.opacity(0.22), radius: 12, x: 0, y: 8)
                    .padding(.bottom, 4)
            }
        }
        .clipped()
        .animation(.easeInOut(duration: 0.08), value: frameIndex)
    }

    private func expressionFrameImage(from image: NSImage) -> NSImage? {
        var proposedRect = CGRect(origin: .zero, size: image.size)
        guard let cgImage = image.cgImage(forProposedRect: &proposedRect, context: nil, hints: nil) else {
            return nil
        }

        let frameWidth = Double(cgImage.width) / Double(expressionFrameCount)
        let x = Int((Double(frameIndex) * frameWidth).rounded(.down))
        let nextX = Int((Double(frameIndex + 1) * frameWidth).rounded(.down))
        let cropWidth = max(1, min(nextX - x, cgImage.width - x))
        let cropRect = CGRect(x: x, y: 0, width: cropWidth, height: cgImage.height)

        guard let cropped = cgImage.cropping(to: cropRect) else {
            return nil
        }

        return NSImage(cgImage: cropped, size: NSSize(width: cropWidth, height: cgImage.height))
    }

    private func loadExpressionSheet() -> NSImage? {
        guard let url = Bundle.main.url(forResource: "CaiWuJunExpressionSheet", withExtension: "png") else {
            return nil
        }
        return NSImage(contentsOf: url)
    }

    private func loadImage() -> NSImage? {
        guard let url = Bundle.main.url(forResource: "CaiWuJunCharacter", withExtension: "png") else {
            return nil
        }
        return NSImage(contentsOf: url)
    }
}

private struct MessageBubble: View {
    let message: ChatMessage

    var body: some View {
        HStack {
            if message.role == .user { Spacer(minLength: 36) }
            Text(message.text)
                .font(.system(size: 14))
                .foregroundStyle(message.role == .user ? .white : Color(red: 0.14, green: 0.15, blue: 0.18))
                .padding(.horizontal, 12)
                .padding(.vertical, 9)
                .background(background, in: RoundedRectangle(cornerRadius: 8))
            if message.role == .assistant { Spacer(minLength: 36) }
        }
    }

    private var background: Color {
        message.role == .user
            ? Color(red: 0.14, green: 0.42, blue: 0.61)
            : Color(red: 1.0, green: 0.94, blue: 0.80)
    }
}

private struct SettingsView: View {
    @Binding var providerRaw: String
    @Binding var apiKey: String
    @Binding var apiBaseURL: String
    @Binding var model: String
    let useCodexDefaults: () -> Void
    let useDoubaoDefaults: () -> Void
    let useOpenAIDefaults: () -> Void
    let useCompatibleDefaults: () -> Void
    let onSave: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("AI 核心设置")
                .font(.system(size: 22, weight: .bold))

            Text("选择一个真实 AI 接口后，蔡武君会把当前窗口上下文发给对应模型。Key 保存在本机 UserDefaults。")
                .font(.system(size: 13))
                .foregroundStyle(.secondary)

            HStack(spacing: 8) {
                Button("本机 Codex") {
                    useCodexDefaults()
                }
                Button("豆包火山方舟") {
                    useDoubaoDefaults()
                }
                Button("OpenAI") {
                    useOpenAIDefaults()
                }
                Button("自定义/本地兼容") {
                    useCompatibleDefaults()
                }
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("接口类型：\(providerLabel)")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(.secondary)

                TextField("接口地址", text: $apiBaseURL)
                    .textFieldStyle(.roundedBorder)

                TextField("模型", text: $model)
                    .textFieldStyle(.roundedBorder)

                SecureField("API Key，例如 ARK_API_KEY 或 sk-...", text: $apiKey)
                    .textFieldStyle(.roundedBorder)
            }

            HStack {
                Spacer()
                Button("保存") {
                    onSave()
                }
                .keyboardShortcut(.defaultAction)
            }
        }
        .padding(22)
    }

    private var providerLabel: String {
        switch AIProviderKind(rawValue: providerRaw) ?? .doubaoArk {
        case .codexCLI:
            return "本机 Codex 登录"
        case .openAIResponses:
            return "OpenAI Responses"
        case .doubaoArk:
            return "豆包火山方舟 Chat"
        case .openAICompatible:
            return "OpenAI 兼容 Chat"
        }
    }
}
