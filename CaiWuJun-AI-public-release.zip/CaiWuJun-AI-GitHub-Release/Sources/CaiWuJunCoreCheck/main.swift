import CaiWuJunCore
import Foundation

func check(_ condition: @autoclosure () -> Bool, _ message: String) {
    if !condition() {
        fputs("Check failed: \(message)\n", stderr)
        exit(1)
    }
}

let morning = Calendar.current.date(from: DateComponents(year: 2026, month: 6, day: 3, hour: 8))!
check(GreetingProvider.greeting(for: morning).contains("早上好"), "morning greeting should mention morning")

let afternoon = Calendar.current.date(from: DateComponents(year: 2026, month: 6, day: 3, hour: 15))!
let afternoonGreeting = GreetingProvider.greeting(for: afternoon)
check(afternoonGreeting.contains("下午好"), "afternoon greeting should mention afternoon")
check(
    afternoonGreeting.contains("任务") || afternoonGreeting.contains("关卡") || afternoonGreeting.contains("小怪"),
    "afternoon greeting should use game-like language"
)

let midnight = Calendar.current.date(from: DateComponents(year: 2026, month: 6, day: 3, hour: 2))!
let midnightGreeting = GreetingProvider.greeting(for: midnight)
check(midnightGreeting.contains("深夜"), "midnight greeting should mention late night")
check(midnightGreeting.contains("温柔") || midnightGreeting.contains("慢一点"), "midnight greeting should be gentle")

check(PersonaPrompt.systemPrompt.contains("蔡武君"), "persona should use Cai Wu Jun name")
check(PersonaPrompt.systemPrompt.contains("游戏"), "persona should mention gaming")
check(PersonaPrompt.systemPrompt.contains("编程"), "persona should mention programming")
check(PersonaPrompt.systemPrompt.contains("拍照"), "persona should mention photography")
check(
    PersonaPrompt.systemPrompt.contains("固定台词") || PersonaPrompt.systemPrompt.contains("预设台词"),
    "persona should reject fixed script behavior"
)
check(PersonaPrompt.systemPrompt.contains("真实思考"), "persona should mention real thinking")
check(PersonaPrompt.prompt(isTeachingMode: true, memoryTitle: "数学").contains("教学模式"), "teaching prompt should mention teaching mode")

let tempURL = FileManager.default.temporaryDirectory.appendingPathComponent("caiwujun-conversations-check-\(UUID().uuidString).json")
let store = ConversationStore(fileURL: tempURL)
let conversation = Conversation(title: "测试窗口", messages: [ChatMessage(role: .assistant, text: "正在重启，尝试重启...")])
try store.save([conversation])
let loaded = try store.load()
check(loaded.count == 1, "conversation store should load saved conversation")
check(loaded.first?.messages.first?.text.contains("正在重启") == true, "conversation store should preserve local context memory")
try? FileManager.default.removeItem(at: tempURL)

let payload = try OpenAIRequestBuilder.payload(
    model: "gpt-5-mini",
    systemPrompt: "你是蔡武君。",
    messages: [ChatMessage(role: .user, text: "你好")]
)
let object = try JSONSerialization.jsonObject(with: payload) as? [String: Any]
check(object?["model"] as? String == "gpt-5-mini", "payload should include model")
check(object?["instructions"] as? String == "你是蔡武君。", "payload should include instructions")
check(object?["input"] != nil, "payload should include input")

let response = """
{
  "output": [
    {
      "content": [
        {
          "type": "output_text",
          "text": "我在，今天我们先打哪一关？"
        }
      ]
    }
  ]
}
""".data(using: .utf8)!
let text = try OpenAIResponseParser.replyText(from: response)
check(text == "我在，今天我们先打哪一关？", "parser should read output_text")

let chatPayload = try ChatCompletionsRequestBuilder.payload(
    model: "doubao-seed-2-0-lite-260215",
    systemPrompt: "你是蔡武君。",
    messages: [ChatMessage(role: .user, text: "教我分数")]
)
let chatObject = try JSONSerialization.jsonObject(with: chatPayload) as? [String: Any]
check(chatObject?["model"] as? String == "doubao-seed-2-0-lite-260215", "chat payload should include model")
check(chatObject?["messages"] != nil, "chat payload should include messages")

let chatResponse = """
{
  "choices": [
    {
      "message": {
        "role": "assistant",
        "content": "分数可以看成把一个整体切成几份。"
      }
    }
  ]
}
""".data(using: .utf8)!
let chatText = try ChatCompletionsResponseParser.replyText(from: chatResponse)
check(chatText == "分数可以看成把一个整体切成几份。", "chat parser should read message content")
check(AIProviderKind(rawValue: "codexCLI") == .codexCLI, "codex cli provider should decode")

let manyMessages = (0..<20).map { index in
    ChatMessage(role: index % 2 == 0 ? .user : .assistant, text: "消息 \(index)")
}
let codexReply = try await CodexCLIClient.send(
    messages: manyMessages + [ChatMessage(role: .user, text: "只回答：稳定测试")],
    systemPrompt: "你是蔡武君。"
)
check(codexReply.contains("稳定测试"), "codex cli should run with app-safe environment")

print("CaiWuJunCoreCheck passed")
