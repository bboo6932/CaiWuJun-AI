import Foundation

public enum GreetingProvider {
    public static func greeting(for date: Date = Date(), calendar: Calendar = .current) -> String {
        let hour = calendar.component(.hour, from: date)

        switch hour {
        case 5...10:
            return "早上好。我刚刚醒了一点点，脑子还在加载，但陪你开始今天这件事，我可以。"
        case 11...13:
            return "中午好，今天已经打到半场了。要不要我帮你整理一下下午该打哪几个小怪？"
        case 14...17:
            return "下午好。这个时间很适合推进一点任务，不用一口气打穿整张地图。"
        case 18...23:
            return "晚上好。夜间模式启动，不过我不会突然变得很神秘，最多一点点。"
        default:
            return "深夜了啊。我在，但我们要温柔一点对待脑子，慢一点说也可以。"
        }
    }
}
