import Foundation

public struct Conversation: Identifiable, Equatable, Codable, Sendable {
    public var id: UUID
    public var title: String
    public var createdAt: Date
    public var updatedAt: Date
    public var isTeachingMode: Bool
    public var messages: [ChatMessage]

    public init(
        id: UUID = UUID(),
        title: String,
        createdAt: Date = Date(),
        updatedAt: Date = Date(),
        isTeachingMode: Bool = false,
        messages: [ChatMessage] = []
    ) {
        self.id = id
        self.title = title
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.isTeachingMode = isTeachingMode
        self.messages = messages
    }
}
