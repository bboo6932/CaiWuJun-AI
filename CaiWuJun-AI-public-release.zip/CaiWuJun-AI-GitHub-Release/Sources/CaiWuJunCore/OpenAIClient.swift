import Foundation

public enum OpenAIError: LocalizedError {
    case missingAPIKey
    case invalidURL
    case codexUnavailable
    case invalidResponse
    case apiError(String)
    case emptyReply

    public var errorDescription: String? {
        switch self {
        case .missingAPIKey:
            return "还没有配置 AI API Key。"
        case .invalidURL:
            return "AI 接口地址不正确。"
        case .codexUnavailable:
            return "本机 Codex AI 后端不可用。"
        case .invalidResponse:
            return "AI 返回的数据格式我没读懂。"
        case .apiError(let message):
            return message
        case .emptyReply:
            return "AI 没有返回文字。"
        }
    }
}

public enum AIProviderKind: String, Codable, CaseIterable, Sendable {
    case codexCLI
    case openAIResponses
    case doubaoArk
    case openAICompatible
}

public struct AIConfiguration: Sendable {
    public var provider: AIProviderKind
    public var apiKey: String
    public var baseURL: String
    public var model: String

    public init(provider: AIProviderKind, apiKey: String, baseURL: String, model: String) {
        self.provider = provider
        self.apiKey = apiKey
        self.baseURL = baseURL
        self.model = model
    }
}

public enum OpenAIRequestBuilder {
    public static func payload(model: String, systemPrompt: String, messages: [ChatMessage]) throws -> Data {
        let input: [[String: Any]] = messages.map { message in
            [
                "role": message.role.rawValue,
                "content": [
                    [
                        "type": "input_text",
                        "text": message.text
                    ]
                ]
            ]
        }

        let object: [String: Any] = [
            "model": model,
            "instructions": systemPrompt,
            "input": input
        ]

        return try JSONSerialization.data(withJSONObject: object)
    }
}

public enum ChatCompletionsRequestBuilder {
    public static func payload(model: String, systemPrompt: String, messages: [ChatMessage]) throws -> Data {
        var chatMessages: [[String: String]] = [
            [
                "role": "system",
                "content": systemPrompt
            ]
        ]
        chatMessages += messages.map { message in
            [
                "role": message.role.rawValue,
                "content": message.text
            ]
        }

        let object: [String: Any] = [
            "model": model,
            "messages": chatMessages
        ]

        return try JSONSerialization.data(withJSONObject: object)
    }
}

public enum OpenAIResponseParser {
    public static func replyText(from data: Data) throws -> String {
        let object = try JSONSerialization.jsonObject(with: data) as? [String: Any]

        if let error = object?["error"] as? [String: Any],
           let message = error["message"] as? String {
            throw OpenAIError.apiError(message)
        }

        guard let output = object?["output"] as? [[String: Any]] else {
            throw OpenAIError.invalidResponse
        }

        let texts = output.flatMap { item -> [String] in
            guard let content = item["content"] as? [[String: Any]] else { return [] }
            return content.compactMap { part in
                guard part["type"] as? String == "output_text" else { return nil }
                return part["text"] as? String
            }
        }

        let reply = texts.joined(separator: "\n").trimmingCharacters(in: .whitespacesAndNewlines)
        guard !reply.isEmpty else { throw OpenAIError.emptyReply }
        return reply
    }
}

public enum ChatCompletionsResponseParser {
    public static func replyText(from data: Data) throws -> String {
        let object = try JSONSerialization.jsonObject(with: data) as? [String: Any]

        if let error = object?["error"] as? [String: Any],
           let message = error["message"] as? String {
            throw OpenAIError.apiError(message)
        }

        guard let choices = object?["choices"] as? [[String: Any]] else {
            throw OpenAIError.invalidResponse
        }

        let texts = choices.compactMap { choice -> String? in
            guard let message = choice["message"] as? [String: Any] else { return nil }
            return message["content"] as? String
        }

        let reply = texts.joined(separator: "\n").trimmingCharacters(in: .whitespacesAndNewlines)
        guard !reply.isEmpty else { throw OpenAIError.emptyReply }
        return reply
    }
}

public struct OpenAIClient: Sendable {
    private let configuration: AIConfiguration
    private let session: URLSession

    public init(apiKey: String, model: String = "gpt-5-mini", session: URLSession = .shared) {
        self.configuration = AIConfiguration(
            provider: .openAIResponses,
            apiKey: apiKey,
            baseURL: "https://api.openai.com/v1",
            model: model
        )
        self.session = session
    }

    public init(configuration: AIConfiguration, session: URLSession = .shared) {
        self.configuration = configuration
        self.session = session
    }

    public func send(messages: [ChatMessage], systemPrompt: String = PersonaPrompt.systemPrompt) async throws -> String {
        if configuration.provider == .codexCLI {
            return try await CodexCLIClient.send(messages: messages, systemPrompt: systemPrompt)
        }

        guard !configuration.apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw OpenAIError.missingAPIKey
        }

        switch configuration.provider {
        case .codexCLI:
            return try await CodexCLIClient.send(messages: messages, systemPrompt: systemPrompt)
        case .openAIResponses:
            return try await sendResponses(messages: messages, systemPrompt: systemPrompt)
        case .doubaoArk, .openAICompatible:
            return try await sendChatCompletions(messages: messages, systemPrompt: systemPrompt)
        }
    }

    private func sendResponses(messages: [ChatMessage], systemPrompt: String) async throws -> String {
        guard let url = URL(string: normalizedBaseURL().appending("/responses")) else {
            throw OpenAIError.invalidURL
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(configuration.apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try OpenAIRequestBuilder.payload(
            model: configuration.model,
            systemPrompt: systemPrompt,
            messages: messages
        )

        let (data, response) = try await session.data(for: request)
        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
            if let message = try? OpenAIResponseParser.replyText(from: data) {
                throw OpenAIError.apiError(message)
            }
            let fallback = String(data: data, encoding: .utf8) ?? "HTTP \(http.statusCode)"
            throw OpenAIError.apiError(fallback)
        }

        return try OpenAIResponseParser.replyText(from: data)
    }

    private func sendChatCompletions(messages: [ChatMessage], systemPrompt: String) async throws -> String {
        guard let url = URL(string: normalizedBaseURL().appending("/chat/completions")) else {
            throw OpenAIError.invalidURL
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(configuration.apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try ChatCompletionsRequestBuilder.payload(
            model: configuration.model,
            systemPrompt: systemPrompt,
            messages: messages
        )

        let (data, response) = try await session.data(for: request)
        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
            if let message = try? ChatCompletionsResponseParser.replyText(from: data) {
                throw OpenAIError.apiError(message)
            }
            let fallback = String(data: data, encoding: .utf8) ?? "HTTP \(http.statusCode)"
            throw OpenAIError.apiError(fallback)
        }

        return try ChatCompletionsResponseParser.replyText(from: data)
    }

    private func normalizedBaseURL() -> String {
        let trimmed = configuration.baseURL.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.hasSuffix("/") ? String(trimmed.dropLast()) : trimmed
    }
}

public enum CodexCLIClient {
    public static func send(messages: [ChatMessage], systemPrompt: String) async throws -> String {
        try await Task.detached(priority: .userInitiated) {
            let executable = try codexExecutable()
            let outputURL = FileManager.default.temporaryDirectory
                .appendingPathComponent("caiwujun-codex-\(UUID().uuidString).txt")
            defer { try? FileManager.default.removeItem(at: outputURL) }

            let prompt = buildPrompt(messages: messages, systemPrompt: systemPrompt)
            let process = Process()
            process.executableURL = executable
            process.arguments = [
                "-a", "never",
                "exec",
                "--ephemeral",
                "--skip-git-repo-check",
                "--sandbox", "read-only",
                "--output-last-message", outputURL.path,
                prompt
            ]
            process.currentDirectoryURL = FileManager.default.temporaryDirectory
            process.environment = codexEnvironment()

            let stderr = Pipe()
            process.standardError = stderr
            try process.run()
            process.waitUntilExit()

            guard process.terminationStatus == 0 else {
                let data = stderr.fileHandleForReading.readDataToEndOfFile()
                let message = String(data: data, encoding: .utf8) ?? "Codex CLI exited with \(process.terminationStatus)"
                throw OpenAIError.apiError(message)
            }

            let reply = try String(contentsOf: outputURL, encoding: .utf8)
                .trimmingCharacters(in: .whitespacesAndNewlines)
            guard !reply.isEmpty else { throw OpenAIError.emptyReply }
            return reply
        }.value
    }

    private static func codexExecutable() throws -> URL {
        let candidates = [
            "/opt/homebrew/bin/codex",
            "/usr/local/bin/codex",
            "/Applications/Codex.app/Contents/Resources/codex"
        ]
        for path in candidates where FileManager.default.isExecutableFile(atPath: path) {
            return URL(fileURLWithPath: path)
        }
        throw OpenAIError.codexUnavailable
    }

    private static func buildPrompt(messages: [ChatMessage], systemPrompt: String) -> String {
        let recentMessages = Array(messages.suffix(10))
        let omittedCount = max(0, messages.count - recentMessages.count)
        let summary = omittedCount > 0
            ? "前面还有 \(omittedCount) 条较早消息，这次为了保持稳定没有完整发送；请根据最近上下文自然延续。"
            : "这是当前窗口的完整近期上下文。"

        let transcript = recentMessages.map { message in
            "\(message.role.rawValue): \(message.text)"
        }.joined(separator: "\n")

        return """
        你现在是一个桌面聊天应用里的角色“蔡武君”。请只输出给用户看的最终回复，不要写工具过程，不要修改文件，不要执行命令。

        \(systemPrompt)

        上下文策略：
        \(summary)

        当前对话：
        \(transcript)

        请用中文自然回复最后一条 user 消息。
        """
    }

    private static func codexEnvironment() -> [String: String] {
        var environment = ProcessInfo.processInfo.environment
        let stablePath = [
            "/opt/homebrew/bin",
            "/usr/local/bin",
            "/usr/bin",
            "/bin",
            "/usr/sbin",
            "/sbin"
        ].joined(separator: ":")
        if let existing = environment["PATH"], !existing.isEmpty {
            environment["PATH"] = "\(stablePath):\(existing)"
        } else {
            environment["PATH"] = stablePath
        }
        environment["SHELL"] = environment["SHELL"] ?? "/bin/zsh"
        return environment
    }
}
