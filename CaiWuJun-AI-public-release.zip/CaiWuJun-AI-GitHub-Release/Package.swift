// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "CaiWuJunAI",
    platforms: [
        .macOS(.v14)
    ],
    products: [
        .library(name: "CaiWuJunCore", targets: ["CaiWuJunCore"]),
        .executable(name: "CaiWuJunCoreCheck", targets: ["CaiWuJunCoreCheck"]),
        .executable(name: "CaiWuJunAI", targets: ["CaiWuJunAI"])
    ],
    targets: [
        .target(name: "CaiWuJunCore"),
        .executableTarget(
            name: "CaiWuJunCoreCheck",
            dependencies: ["CaiWuJunCore"]
        ),
        .executableTarget(
            name: "CaiWuJunAI",
            dependencies: ["CaiWuJunCore"]
        )
    ]
)
